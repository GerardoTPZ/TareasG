class Seguro {
  constructor(base) {
    this.base = base;
  }

  recargoEdad(edad) {
    if (edad >= 18 && edad <= 24) {
      return this.base * 0.1;
    } else if (edad >= 25 && edad <= 49) {
      return this.base * 0.2;
    } else if (edad >= 50) {
      return this.base * 0.3;
    } else {
      return 0;
    }
  }

  recargoPareja(edadPareja) {
    return this.recargoEdad(edadPareja);
  }

  recargoHijos(numHijos) {
    return numHijos * (this.base * 0.2);
  }

  calcular(edad, casado, edadPareja, numHijos) {
    if (edad < 18) {
      return "El asegurado debe ser mayor de edad.";
    }

    let total = this.base + this.recargoEdad(edad);
    total += casado ? this.recargoPareja(edadPareja) : 0;
    total += casado ? this.recargoHijos(numHijos) : 0;

    return total;
  }
}

let seguro = new Seguro(2000);

let edad = parseInt(prompt("Ingrese su edad:"));
if (edad < 18) {
  console.log("El asegurado debe ser mayor de edad.");
} else {
  let casado = confirm("¿Está casado? (Aceptar para sí, Cancelar para no)");
  let edadPareja = casado
    ? parseInt(prompt("Ingrese la edad de su pareja:"))
    : 0;
  let numHijos = casado ? parseInt(prompt("Ingrese la cantidad de hijos:")) : 0;

  let precio = seguro.calcular(edad, casado, edadPareja, numHijos);
  console.log("El precio total del seguro es: Q." + precio);
}
