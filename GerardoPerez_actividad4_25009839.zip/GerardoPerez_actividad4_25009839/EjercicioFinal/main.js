// Explicación de los Incisos Completados
// Conversión de la cantidad de hijos a número:
// Se convierte la cantidad de hijos a un número entero para poder realizar cálculos matemáticos.
// Recargo por la edad del cónyuge:
// Si el asegurado está casado, se calcula el recargo basado en la edad del cónyuge utilizando los mismos rangos de edad que para el asegurado.
// Recargo por la cantidad de hijos:
// Se calcula un recargo del 20% por cada hijo y se suma al recargo total.

//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Algoritmo Propuesto
// Inicialización:

// Definir el precio base del seguro.

// Definir los porcentajes de recargo para cada rango de edad y para los hijos.

// Entrada de datos:

// Solicitar al usuario su nombre, edad, estado civil, edad del cónyuge (si está casado) y cantidad de hijos.

// Conversión de datos:

// Convertir las edades y la cantidad de hijos a números enteros.

// Cálculo de recargos:

// Recargo por edad del asegurado: Aplicar el porcentaje correspondiente según el rango de edad.

// Recargo por edad del cónyuge: Si está casado, aplicar el porcentaje correspondiente según el rango de edad del cónyuge.

// Recargo por cantidad de hijos: Aplicar un 20% por cada hijo.

// Cálculo del precio final:

// Sumar todos los recargos al precio base.

// Salida de resultados:

// Mostrar el recargo total y el precio final al usuario.

//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

class Seguro {
  constructor(base) {
    this.base = base;
  }

  recargoEdad(edad) {
    if (edad >= 18 && edad <= 24) {
      return this.base * 0.1;
    } else if (edad >= 25 && edad <= 49) {
      return this.base * 0.2;
    } else if (edad >= 50) {
      return this.base * 0.3;
    } else {
      return 0;
    }
  }

  recargoPareja(edadPareja) {
    return this.recargoEdad(edadPareja);
  }

  recargoHijos(numHijos) {
    return numHijos * (this.base * 0.2);
  }

  calcular(edad, casado, edadPareja, numHijos) {
    if (edad < 18) {
      return "El asegurado debe ser mayor de edad.";
    }

    let total = this.base + this.recargoEdad(edad);
    total += casado ? this.recargoPareja(edadPareja) : 0;
    total += casado ? this.recargoHijos(numHijos) : 0;

    return total;
  }
}

let seguro = new Seguro(2000);

let edad = parseInt(prompt("Ingrese su edad:"));
if (edad < 18) {
  console.log("El asegurado debe ser mayor de edad.");
} else {
  let casado = confirm("¿Está casado? (Aceptar para sí, Cancelar para no)");
  let edadPareja = casado
    ? parseInt(prompt("Ingrese la edad de su pareja:"))
    : 0;
  let numHijos = casado ? parseInt(prompt("Ingrese la cantidad de hijos:")) : 0;

  let precio = seguro.calcular(edad, casado, edadPareja, numHijos);
  console.log("El precio total del seguro es: Q." + precio);
}
